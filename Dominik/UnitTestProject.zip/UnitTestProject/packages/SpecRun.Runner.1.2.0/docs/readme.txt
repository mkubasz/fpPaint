﻿SpecRun Documentation
=====================

Please check our website (http://www.specrun.com) for introduction videos and 
upcoming documentation content.

SpecRun supports executing pure NUnit tests too. Please check NUnitSupport.txt
for details. 

The file SpecRun.speclog (or the HTML exported copy, SpecRun_Docs.html) contains
the requirement repository of SpecRun, including the automated Gherkin scenarios 
that have been verified when this package was created. We hope they can answer 
some questions about the product.

SpecLog is a visual requirement management tool from the creators of SpecFlow 
and SpecRun. You can open and read the attached SpecRun.speclog file with the
evaluation version of SpecRun. See more details at http://www.speclog.net/.

If you have any further questions, please contact us at http://specrun.zendesk.com/, 
or post to our dicsussion forum: http://groups.google.com/group/specrun.
